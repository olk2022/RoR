# Идеальный вес
	
rescue StandardError => e
	
end
puts "Укажите ваше имя"
name = gets.chomp.capitalize

puts "Укажите ваш рост"
height = gets.chomp

idel_weight = (height.to_i - 110) * 1.15

if idel_weight > 0
	puts "#{name}, ваш идеальный вес #{idel_weight} кг"
else 
	puts "Ваш вес уже оптимальный"
end