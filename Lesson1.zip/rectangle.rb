# Прямоугольный треугольник
# one - длина первой стороны треугольника    
# two - длина второй стороны треугольника
# three - длина третье стороны треугольника

puts "Введите длину первой стороны треугольника"
one = gets.chomp

puts "Введите длину второй стороны треугольника"
two = gets.chomp

puts "Введите длину третьей стороны треугольника"
three = gets.chomp

if one.to_i**2 + two.to_i**2 == three.to_i**2 || two.to_i**2 + three.to_i**2 == one.to_i**2 || one.to_i**2 + three.to_i**2 == two.to_i**2
	puts "Прямоугольный треугольник"
elsif one == two && one != three  && two != three|| one == three && one != two && three != two || two == three && two != one && three != one
	puts "Прямоугольник равнобедренный"
elsif one == two && two == three && one == three
	puts "Прямоугольник равносторонний"
else
	puts "Что-то пошло не так повторите попытку"
end

