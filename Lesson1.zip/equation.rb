# Квадратное уравнение
# a,b,c - коэффициенты 
# d - дискриминант
# x1, x2 - корни если d > 0

puts "Введите коэффициент a"
a = gets.chomp

puts "Введите коэффициент b"
b = gets.chomp

puts "Введите коэффициент c"
c = gets.chomp

d = b.to_i ** 2 - 4 * a.to_i * b.to_i

if d > 0
	x1 = -b.to_i + Math.sqrt(d.to_i) / 2 * a.to_i
	x2 = -b.to_i - Math.sqrt(d.to_i) / 2 * a.to_i
	puts "Дискриминант равен #{d}, корень1 равен #{x1}, корень2 равен #{x2}."
elsif d == 0
	x1 = -b.to_i / (2* a.to_i)
	puts "Дискриминант равен #{d}, корень равен #{x1}."
else d < 0
	puts "Дискриминант равен #{d}, кореней нет."
end

